#ifndef HELLO_H
#define HELLO_H

class Hello
{
	public:
		void printHello(void);
};
#endif