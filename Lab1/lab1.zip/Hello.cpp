#include "Hello.h"
#include <iostream>
using namespace std;

void Hello::printHello()
{
	cout<<"Hello World!"<<endl;
	cout<<"C++ Data Structures!"<<endl;
	cout<<"Hello from the Hello Class!"<<endl;

}