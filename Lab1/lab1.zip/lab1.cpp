#include "Hello.h"
#include <iostream>
int main()
{
        Hello hello;
        hello.printHello();
        return 0;
}