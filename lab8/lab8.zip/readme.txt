Name: Salem Alqahtani

salqaht1@binghamton.edu

This is implementations for mergesort, quicksort, and heapsort.

I did not implement sort optimization but I just for for the extra 5 points by just implement the third sort.



All are running and I included c++ extension for makefile. However, I did test it on the lab machine and my machine and it was working and good but when I uploaded it on Mimir, there is an error. it’s saying that I failed in one of the tests. In lab machine I passed all the test.


Sincerely




